/*
 Naam  : teamm-versie.js
 Datum : 15-05-2016
 Auteur: Henk Kruize
 
 Ophalen menu + rooster en opslaan in lokale storage

*/
function lees_data(p_online) {
    var l_online = p_online;
		
    if (l_online=='1') {
	var url='http://ts.teamm.nl:8195/ords/apex_rest.getReport?app='+localStorage.getItem('teammapp')+'&page=rooster&reportid=teammenu&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teammenu', JSON.stringify(json));
	    lees_menu(json);
	    });
	}
    else {	     
	lees_menu(JSON.parse(localStorage.getItem('teammenu')));
	} //norefresh
    $('nav#menu').mmenu();
}