/*
 Naam  : teamm-rooster.js
 Datum : 15-05-2016
 Auteur: Henk Kruize
 
 Ophalen menu + rooster en opslaan in lokale storage

*/
function lees_data(p_online) {
    var l_online = p_online;
		
    if (l_online=='1') {
	if (sessionStorage.teamonline=='Y') {
	    $("#teamm-berichtenkop").html('<a href="bericht-maken.html"><img src="images/teamm-bericht.png" alt=""></a>');
	}
			
	/* Er is internetverbinding */
	/*var url='http://ts.teamm.nl:8195/apex/apex_rest.getReport?app=rfmapp&page=10&reportid=teammenu&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teammenu', JSON.stringify(json));
	    lees_menu(json);
	    });*/
	var url='http://ts.teamm.nl:8195/ords/apex_rest.getReport?app='+localStorage.getItem('teammapp')+'&page=berichten&reportid=berichten&parmvalues='+localStorage.getItem('teamprofiel')+','+localStorage.getItem('teamklant')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teammberichten', JSON.stringify(json));
	    lees_berichten(json);
	    });
	
	}
    else {
	if (sessionStorage.teamonline=='Y') {
	    $("#teamm-berichtenkop").html('<a href="bericht-maken.html"><img src="images/teamm-bericht.png" alt=""></a>');
	}	
	/* Er is geen internetverbinding, haal lokale data op */
	//lees_menu(JSON.parse(localStorage.getItem('teammenu')));
	lees_berichten(JSON.parse(localStorage.getItem('teammberichten')));
	} 
    $('nav#menu').mmenu();
}