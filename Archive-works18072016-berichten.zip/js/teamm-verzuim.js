/*
 Naam  : teamm-rooster.js
 Datum : 15-05-2016
 Auteur: Henk Kruize
 
 Ophalen menu + rooster en opslaan in lokale storage

*/
function lees_data(p_online) {
    var l_online = p_online;
		
    if (l_online=='1') {
	if (sessionStorage.teamonline=='Y') {
	    $("#teamm-verzuimkop").html('<img id="verzuimtoev" src="images/teamm-cal-unchecked.png" alt="">');
	}
	$("#teamm-verzuimkop").html('<img id="verzuimtoev" src="images/teamm-cal-unchecked.png" alt="">');
	/* Er is internetverbinding */
	/*var url='http://ts.teamm.nl:8195/apex/apex_rest.getReport?app=rfmapp&page=10&reportid=teammenu&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teammenu', JSON.stringify(json));
	    lees_menu(json);
	    });*/
	var url='http://ts.teamm.nl:8195/ords/apex_rest.getReport?app='+localStorage.getItem('teammapp')+'&page=rooster&reportid=verzuim&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teammverzuim', JSON.stringify(json));
	    lees_verzuim(json);
	    });
	
	}
    else {
	/* Er is geen internetverbinding, haal lokale data op */
	//lees_menu(JSON.parse(localStorage.getItem('teammenu')));
	if (sessionStorage.teamonline=='Y') {
	    $("#teamm-verzuimkop").html('<img id="verzuimtoev" src="images/teamm-cal-unchecked.png" alt="">');
	}
	lees_verzuim(JSON.parse(localStorage.getItem('teammverzuim')));
	} 
 //   $('nav#menu').mmenu();
}