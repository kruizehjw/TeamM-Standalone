    /*
 Naam  : teamm-rooster.js
 Datum : 15-05-2016
 Auteur: Henk Kruize
 
 Ophalen menu + rooster en opslaan in lokale storage

*/
function lees_data(p_online) {
    var l_online = p_online;
		
    if (l_online=='1') {
//	var url='http://ts.teamm.nl:8195/ords/apex_rest.getReport?app='+localStorage.getItem('teammapp')+'&page=berichten&reportid=berichten&parmvalues='+localStorage.getItem('teamprofiel')+','+localStorage.getItem('teamklant')+'&output=json';
//    	$.getJSON(url,function(json) {
//	    localStorage.setItem('teammberichten', JSON.stringify(json));
//	    lees_berichten(json);
//	    });

          l_klant      = localStorage.teamklant;
	  l_medewerker = localStorage.getItem('teamprofiel');
	  var content  = '<select id="ontvangerid" style="width: 40%;padding: 16px 20px;border: none;margin:20px 15px 2px 15px;border-radius: 4px;font-size:20px;background-color: #f1f1f1;">';
	  var content2 = '<select id="ontvangerid2" style="width: 40%;padding: 16px 20px;border: none;margin:20px 15px 2px 15px;border-radius: 4px;font-size:20px;background-color: #f1f1f1;">';
	  $.ajax({
                    url: "http://ts.teamm.nl:8195/ords/"+localStorage.getItem('teamuri')+"/berichtgrp",
                    type: "GET",
                    dataType: "json",
                    headers:{"medewerker"    : l_medewerker,
		             "klant"         : l_klant
                            },
                    success: function (data,status,jqXHR) {
			if (JSON.stringify(data)!='null') { //storage of remote heeft waarde
			    $.each(data.items,function(i,tweet) {
			      content += '<option value="'+tweet.organisatie_onderdeel+'">'+tweet.organisatie_onderdeel+'</option>';
			      $.each(tweet.collega,function(i,tweet2) {
				content2 += '<option value="'+tweet2.collega_code+'">'+tweet2.collega_naam+'</option>';
			      })
			    });
                            content  += '</select>';
			    content2 += '</select>';
			    content += content2;
			    $("#berichtgrp").html(content);
			    //$("#berichtgrp2").html(content2);
                        }
		      }	,
                    error: function(jqXHR,status) {
                            alert('Service of server niet beschikbaar');
                            }
                    });

	
	}
    else {
	if (sessionStorage.teamonline=='Y') {
	    $("#teamm-berichtenkop").html('<a href="bericht-maken.html"><img src="images/teamm-bericht.png" alt=""></a>');
	}	
	/* Er is geen internetverbinding, haal lokale data op */
	//lees_menu(JSON.parse(localStorage.getItem('teammenu')));
	lees_berichten(JSON.parse(localStorage.getItem('teammberichten')));
	}
   // $('nav#menu').mmenu();
}